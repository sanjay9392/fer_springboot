package com.rs.fer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication
@PropertySource("classpath:${ENV_NAME}/application.properties")
public class FERSpringBootJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FERSpringBootJpaApplication.class, args);
	}

}
