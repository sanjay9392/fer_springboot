package com.rs.fer.ipl.service.impl;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetTeamsRequest {

	private String name;
}
