package com.core.amstrong.ex;

public abstract class MyCalculator extends Calculator {
	  @Override
	  public int add(int a, int b) {
	    return a + b; 
	  }
	  
	 Calculator mycal = new MyCalculator() {

		@Override
		public int subtract(int a, int b) {
			return 0;
		}
		
	 };
	int result = mycal.add(5,2);
	
}
