package com.core.even_odd.ex;

public class SquareRoot_Ex {

	public static void main(String[] args) {
		double n = 15;
		double squareroot = Math.sqrt(n);
		System.out.println("The Squareroot of " + n + " is : " + squareroot);
	}

}
