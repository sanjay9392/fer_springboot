package com.core.even_odd.ex;

public class Even_Or_Odd_Check {

	public static void main(String[] args) {

		int n = 10;
		if(n % 2 == 0) {
			System.out.println(n + " "+ "is a Even Number");
		}else {
			System.out.println(n + " "+ "is a odd Number");

		}
	}

}
